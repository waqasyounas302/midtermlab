from datetime import datetime
import random

def generate_postcard_code(country_code="XX"):
    num = random.randint(100000, 999999)
    return f"{country_code}-{num}"

def postcard_doc(sender_id, sender_address_id, recipient_id, recipient_address_id, origin_country, destination_country):
    return {
        "postcard_code": generate_postcard_code(origin_country),
        "sender_id": sender_id,
        "sender_address_id": sender_address_id,
        "recipient_id": recipient_id,
        "recipient_address_id": recipient_address_id,
        "created_at": datetime.utcnow(),
        "assigned_at": datetime.utcnow(),
        "sent_at": None,
        "delivered_at": None,
        "status": "assigned",  # assigned|sent|delivered|cancelled
        "message": "",
        "tags": [],
        "language": "English",
        "origin_country": origin_country,
        "destination_country": destination_country,
        "is_reciprocal": False,
        "matched_with": None,
        "history": []
    }

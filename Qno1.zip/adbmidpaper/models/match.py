from datetime import datetime

def match_doc(match_type, user_id, country):
    return {
        "type": match_type,  # recipient_need | open_sender_slot
        "user_id": user_id,
        "country": country,
        "created_at": datetime.utcnow(),
        "expires_at": None,
        "payload": {}
    }

from datetime import datetime

def address_doc(user_id, recipient_name, line1, city, country, postal_code):
    return {
        "user_id": user_id,
        "recipient_name": recipient_name,
        "line1": line1,
        "city": city,
        "country": country,
        "postal_code": postal_code,
        "is_verified": False,
        "created_at": datetime.utcnow()
    }

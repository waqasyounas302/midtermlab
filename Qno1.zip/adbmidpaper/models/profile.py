from datetime import datetime

def profile_doc(user_id, display_name, country, address_id):
    return {
        "user_id": user_id,
        "display_name": display_name,
        "country": country,
        "city": "",
        "bio": "",
        "language": "English",
        "willing_to_receive_from": ["ANY"],
        "willing_to_send_to": ["ANY"],
        "max_simultaneous_outgoing": 5,
        "allow_random_matches": True,
        "visible": True,
        "address_id": address_id,
        "stats": {
            "sent": 0,
            "received": 0,
            "rating": 0
        },
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }

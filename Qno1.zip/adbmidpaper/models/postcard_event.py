from datetime import datetime

def event_doc(postcard_id, event_type, by_user_id, metadata=None):
    return {
        "postcard_id": postcard_id,
        "type": event_type,  # assigned|sent|delivered|comment|report
        "by_user_id": by_user_id,
        "metadata": metadata or {},
        "created_at": datetime.utcnow()
    }

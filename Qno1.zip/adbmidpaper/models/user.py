from datetime import datetime

def user_doc(username, email, password_hash):
    return {
        "username": username,
        "email": email,
        "password_hash": password_hash,
        "is_active": True,
        "roles": ["user"],
        "created_at": datetime.utcnow(),
        "last_login": None
    }

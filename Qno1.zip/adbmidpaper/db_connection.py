from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "postcrossing"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]

print(" Connected to MongoDB successfully!")

from db_connection import db
from models.user import user_doc
from models.profile import profile_doc
from models.address import address_doc
from models.postcard import postcard_doc

# Clear collections (only for demo)
db.users.delete_many({})
db.profiles.delete_many({})
db.addresses.delete_many({})
db.postcards.delete_many({})


u1 = db.users.insert_one(user_doc("ali", "ali@example.com", "hashed_pw")).inserted_id
u2 = db.users.insert_one(user_doc("maria", "maria@example.com", "hashed_pw")).inserted_id


a1 = db.addresses.insert_one(address_doc(u1, "Ali", "Street 12", "Lahore", "PK", "54000")).inserted_id
a2 = db.addresses.insert_one(address_doc(u2, "Maria", "Calle 5", "Santiago", "CL", "8320000")).inserted_id


db.profiles.insert_one(profile_doc(u1, "Ali", "PK", a1))
db.profiles.insert_one(profile_doc(u2, "Maria", "CL", a2))


p1 = db.postcards.insert_one(postcard_doc(u1, a1, u2, a2, "PK", "CL")).inserted_id

print(" Sample data inserted successfully!")

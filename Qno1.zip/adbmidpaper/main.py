# main.py
from db_connection import db
from pprint import pprint

print("\n==================== USERS ====================")
for u in db.users.find():
    pprint(u)

print("\n==================== ADDRESSES ====================")
for a in db.addresses.find():
    pprint(a)

print("\n==================== PROFILES ====================")
for p in db.profiles.find():
    pprint(p)

print("\n==================== POSTCARDS ====================")
for c in db.postcards.find():
    pprint(c)

# Optional: show postcards with sender/recipient usernames
print("\n==================== POSTCARDS DETAILS ====================")
for c in db.postcards.find():
    sender = db.users.find_one({"_id": c["sender_id"]})
    recipient = db.users.find_one({"_id": c["recipient_id"]})
    print(f"📮 {c['postcard_code']} | From: {sender['username']} | To: {recipient['username']} | Status: {c.get('status')}")

from flask import Flask
from api.routes import api_bp
from db_connection import db
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

app.register_blueprint(api_bp, url_prefix="/api")

@app.route("/")
def home():
    return "PostCrossing API is running! Access endpoints at /api/", 200

if __name__ == "__main__":
    app.run(debug=True)

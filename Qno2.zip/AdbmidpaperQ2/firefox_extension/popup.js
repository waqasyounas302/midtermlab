document.addEventListener("DOMContentLoaded", function() {
  const sendBtn = document.getElementById("sendBtn");
  const sortBtn = document.getElementById("sortBtn");
  const status = document.getElementById("status");


  sendBtn.addEventListener("click", function() {
    status.textContent = "Sending postcard...";
    fetch("http://127.0.0.1:5000/api/send_postcard", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        sender_id: "68f5596d19decab244818e15",
        recipient_id: "68f5596d19decab244818e16",
        origin_country: "PK",
        destination_country: "CL"
      })
    })
    .then(response => response.json())
    .then(data => {
      status.textContent = data.message || "Postcard sent!";
      alert(data.message || "Postcard sent!");
    })
    .catch(err => {
      console.error("Error:", err);
      status.textContent = "Failed to send postcard. Check Flask server.";
      alert("Failed to send postcard. Check Flask server.");
    });
  });

  // Sort Tabs
  sortBtn.addEventListener("click", function() {
    status.textContent = "Sorting tabs...";
    browser.runtime.sendMessage({action: "sort_tabs"}).then((response) => {
      if(response && response.status === "success"){
        status.textContent = response.message;
      } else {
        status.textContent = "Failed to sort tabs.";
      }
    });
  });
});

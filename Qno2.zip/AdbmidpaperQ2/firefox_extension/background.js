console.log("PostCrossing Tab Sorter background script running");

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "sort_tabs") {
    browser.tabs.query({}).then((tabs) => {
      let cardTabs = tabs.filter(tab => tab.url.includes("postcrossing.com/postcards/"));

      cardTabs.sort((a, b) => {
        let numA = parseInt(a.url.split("/").pop().split("-").pop());
        let numB = parseInt(b.url.split("/").pop().split("-").pop());
        return numA - numB;
      });

      cardTabs.forEach((tab, index) => {
        browser.tabs.move(tab.id, {index: index});
      });

      sendResponse({status: "success", message: "Tabs sorted!"});
    });

    return true;
  }
});

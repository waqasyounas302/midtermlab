from flask import (Blueprint, jsonify, request)
from datetime import datetime
from db_connection import db
from bson.objectid import ObjectId

api_bp = Blueprint("api_bp", __name__)


def convert_objectid(obj):
    if isinstance(obj, list):
        return [convert_objectid(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_objectid(v) for k, v in obj.items()}
    elif isinstance(obj, ObjectId):
        return str(obj)
    else:
        return obj



@api_bp.route("/users", methods=["GET"])
def get_users():
    users = list(db.users.find({}, {"password_hash": 0}))
    users = convert_objectid(users)
    return jsonify(users), 200



@api_bp.route("/postcards", methods=["GET"])
def get_postcards():
    postcards = list(db.postcards.find())
    postcards = convert_objectid(postcards)
    return jsonify(postcards), 200


@api_bp.route("/send_postcard", methods=["POST"])
def send_postcard():
    data = request.json

    required_fields = ["sender_id", "recipient_id", "origin_country", "destination_country"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400

    try:
        sender_id = ObjectId(data["sender_id"])
        recipient_id = ObjectId(data["recipient_id"])
    except:
        return jsonify({"error": "Invalid sender_id or recipient_id format (must be a valid ObjectId)"}), 400


    sender_addr = db.addresses.find_one({"user_id": sender_id})
    recipient_addr = db.addresses.find_one({"user_id": recipient_id})

    if not sender_addr or not recipient_addr:
        return jsonify({"error": "Address not found for sender or recipient"}), 404


    new_postcard = {
        "postcard_code": data.get("postcard_code", "XX-000000"),
        "sender_id": sender_id,
        "recipient_id": recipient_id,
        "sender_address_id": sender_addr["_id"],
        "recipient_address_id": recipient_addr["_id"],
        "origin_country": data["origin_country"],
        "destination_country": data["destination_country"],
        "status": "assigned",
        "assigned_at": datetime.now(),
        "is_reciprocal": False
    }

    result = db.postcards.insert_one(new_postcard)
    postcard_ids = [str(result.inserted_id)]


    if data.get("reciprocal", False):
        reciprocal_postcard = {
            "postcard_code": data.get("reciprocal_code", "XX-000001"),
            "sender_id": recipient_id,
            "recipient_id": sender_id,
            "sender_address_id": recipient_addr["_id"],
            "recipient_address_id": sender_addr["_id"],
            "origin_country": data["destination_country"],
            "destination_country": data["origin_country"],
            "status": "assigned",
            "assigned_at": datetime.now(),
            "is_reciprocal": True
        }
        recip_result = db.postcards.insert_one(reciprocal_postcard)
        postcard_ids.append(str(recip_result.inserted_id))

        return jsonify({
            "message": "Postcard and reciprocal postcard sent successfully!",
            "postcard_ids": postcard_ids
        }), 201

    return jsonify({
        "message": "Postcard sent successfully!",
        "postcard_id": postcard_ids[0]
    }), 201

from db_connection import db 
from datetime import datetime
import bson
ObjectId = bson.objectid.ObjectId




db.users.delete_many({})
db.addresses.delete_many({})
db.postcards.delete_many({})


user1_id = db.users.insert_one({
    "username": "ali",
    "email": "ali@example.com",
    "password_hash": "hashed_pw",
    "roles": ["user"],
    "is_active": True,
    "created_at": datetime.now(),
    "last_login": None
}).inserted_id

user2_id = db.users.insert_one({
    "username": "maria",
    "email": "maria@example.com",
    "password_hash": "hashed_pw",
    "roles": ["user"],
    "is_active": True,
    "created_at": datetime.now(),
    "last_login": None
}).inserted_id


addr1_id = db.addresses.insert_one({
    "user_id": user1_id,
    "recipient_name": "Ali",
    "line1": "Street 12",
    "city": "Lahore",
    "country": "PK",
    "postal_code": "54000",
    "is_verified": True,
    "created_at": datetime.now()
}).inserted_id

addr2_id = db.addresses.insert_one({
    "user_id": user2_id,
    "recipient_name": "Maria",
    "line1": "Calle 5",
    "city": "Santiago",
    "country": "CL",
    "postal_code": "8320000",
    "is_verified": True,
    "created_at": datetime.now()
}).inserted_id

print(f" Sample data inserted successfully!")
print(f"   User 1 ID (Ali): {user1_id}")
print(f"   User 2 ID (Maria): {user2_id}")
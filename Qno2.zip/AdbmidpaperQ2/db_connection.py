from pymongo import MongoClient

# HARDCODED CONFIGURATION AS REQUESTED
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "postcrossing"

# Connect to MongoDB
try:
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    # Check connection
    client.admin.command('ismaster')
    print(f"✅ Connected to MongoDB: {DB_NAME}")
except Exception as e:
    print(f" Could not connect to MongoDB at {MONGO_URI}: {e}")
    raise